package com.specl.glory.servlet;

import java.io.IOException;

import javax.servlet.FilterConfig;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class LoginServlet extends HttpServlet {

    private static final long serialVersionUID = 7692880158400964584L;
    
    private String LOGIN_NAME,PASSWORD = null;
    
    private static final String USER_LOGIN_NAME_COOKIES_NAME = "un";
    
    private static final String USER_PASSWD_COOKIES_NAME = "pwd";
    
    public void init(ServletConfig cfg) throws ServletException {
        this.LOGIN_NAME = cfg.getInitParameter("LOGIN_NAME");
        this.PASSWORD = cfg.getInitParameter("PASSWORD");
    }
    
    public void doGet(HttpServletRequest request, HttpServletResponse response){
        doPost(request, response);
    }
    
    public void doPost(HttpServletRequest request, HttpServletResponse response){
        
        String action = request.getParameter("action").trim();
        
        if("showLogin".equals(action)){
            showLogin(request, response);
        }
        
        if("login".equals(action)){
            login(request, response);
        }
        
        if("logout".equals(action)){
            logout(request, response);
        }
    }


    private void showLogin(HttpServletRequest request, HttpServletResponse response) {
        try {
            request.getRequestDispatcher("/WEB-INF/jsp/login.jsp").forward(request, response);
        } catch (ServletException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    private void login(HttpServletRequest request, HttpServletResponse response) {
        String userName = request.getParameter("userName").trim();
        String password = request.getParameter("password");
        if (!this.LOGIN_NAME.equals(userName)||!this.PASSWORD.equals(password)) {
            try {
                response.sendRedirect("login.do?action=showLogin");
            } catch (IOException e) {
                e.printStackTrace();
            }
        }else{
            Cookie uncookies = new Cookie(USER_LOGIN_NAME_COOKIES_NAME, userName);
            uncookies.setMaxAge(60 * 60 * 24 * 1);
            uncookies.setPath("/");
            response.addCookie(uncookies);
            
            Cookie pdcookies = new Cookie(USER_PASSWD_COOKIES_NAME, password);
            pdcookies.setMaxAge(60 * 60 * 24 * 1);
            pdcookies.setPath("/");
            response.addCookie(pdcookies);
            try {
                response.sendRedirect("setup.action?action=listJobs");
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
    
    private void logout(HttpServletRequest request, HttpServletResponse response) {
        Cookie[] cookies = request.getCookies();
        if (cookies != null) {
            for (int i = 0; i < cookies.length; i++) {
                Cookie c = cookies[i];
                c.setMaxAge(0);
                response.addCookie(c);
            }
        }
        
        try {
            response.sendRedirect("login.action?action=showLogin");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
