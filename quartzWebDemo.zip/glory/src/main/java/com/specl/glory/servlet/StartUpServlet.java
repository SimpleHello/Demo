package com.specl.glory.servlet;

import static org.quartz.DateBuilder.evenMinuteDate;
import static org.quartz.JobBuilder.newJob;
import static org.quartz.SimpleScheduleBuilder.simpleSchedule;
import static org.quartz.TriggerBuilder.newTrigger;
import static org.quartz.CronScheduleBuilder.cronSchedule;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.net.URL;
import java.net.URLEncoder;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.quartz.CronExpression;
import org.quartz.CronTrigger;
import org.quartz.JobDataMap;
import org.quartz.JobDetail;
import org.quartz.JobKey;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.SchedulerFactory;
import org.quartz.SimpleTrigger;
import org.quartz.Trigger;
import org.quartz.CronTrigger;
import org.quartz.Trigger.TriggerState;
import org.quartz.TriggerKey;
import org.quartz.impl.StdSchedulerFactory;
import org.quartz.impl.matchers.GroupMatcher;
import org.quartz.impl.matchers.StringMatcher;
import org.quartz.impl.matchers.StringMatcher.StringOperatorName;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.specl.glory.jobs.HelloJob;

public class StartUpServlet extends HttpServlet {

    private static final long serialVersionUID = 2080554737893412015L;

    private static final Logger logger = LoggerFactory.getLogger(StartUpServlet.class);

    private static final String PACKAGE_BASE = "com.specl.glory.jobs";
    
    private SchedulerFactory schedulerFactory = null;

    private Map<String,List<String>> jobClassesMap = null;
    
    public void init(ServletConfig cfg) throws ServletException {
        super.init(cfg);
        schedulerFactory = new StdSchedulerFactory();
        Scheduler scheduler = null;
        try {
            scheduler = schedulerFactory.getScheduler();
            scheduler.start();
        } catch (SchedulerException e) {
            e.printStackTrace();
        }
        
        if(jobClassesMap == null){
            jobClassesMap = new HashMap<String, List<String>>();
        }
        
        //扫描任务类
        URL base = StartUpServlet.class.getClassLoader().getResource("/");
        String basePath = base.getFile();
        String baseJobPackage = basePath + PACKAGE_BASE.replaceAll("\\.", "/");
        getAllJobClasses(basePath, baseJobPackage);
    }

    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException {
        doGet(request, response);
    }

    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException {
        String action = request.getParameter("action");
        if ("showAddJob".equals(action)) {
            try {
                showAddJob(request, response);
            } catch (SchedulerException e) {
                e.printStackTrace();
            }
        }
        if ("addJob".equals(action)) {
            try {
                addJob(request, response);
            } catch (SchedulerException e) {
                e.printStackTrace();
            }
        }
        if ("showEditJob".equals(action)) {
            try {
                showEditJob(request, response);
            } catch (SchedulerException e) {
                e.printStackTrace();
            }
        }
        if ("editJob".equals(action)) {
            try {
                editJob(request, response);
            } catch (SchedulerException e) {
                e.printStackTrace();
            }
        }
        if ("deleteJob".equals(action)) {
            try {
                deleteJob(request, response);
            } catch (SchedulerException e) {
                e.printStackTrace();
            }
        }
        if ("listJobs".equals(action)) {
            try {
                listJobs(request, response);
            } catch (SchedulerException e) {
                e.printStackTrace();
            }
        }
        
        if("listJobClasses".equals(action)){
            listJobClasses(request, response);
        }
        if("pauseJob".equals(action)){
            try {
                pauseJob(request,response);
            } catch (SchedulerException e) {
                e.printStackTrace();
            }
        }
        if("resumeJob".equals(action)){
            try {
                resumeJob(request, response);
            } catch (SchedulerException e) {
                e.printStackTrace();
            }
        }
        if("pauseOrRunAllJobs".equals(action)){
            try {
                pauseOrRunAllJobs(request, response);
            } catch (SchedulerException e) {
                e.printStackTrace();
            }
        }
        if("executeOnce".equals(action)){
            try {
                executeOnce(request, response);
            } catch (SchedulerException e) {
                e.printStackTrace();
            }
        }
    }

    private void showAddJob(HttpServletRequest request, HttpServletResponse response) throws SchedulerException {
        String queryGroup = request.getParameter("queryGroup");
        String queryJobName = request.getParameter("queryJobName");
        
        Scheduler scheduler = schedulerFactory.getScheduler();
        List<String> jobGroups = scheduler.getJobGroupNames();
        request.setAttribute("jobGroups", jobGroups);
        request.setAttribute("queryGroup", queryGroup);
        request.setAttribute("queryJobName", queryJobName);
        try {
            request.getRequestDispatcher("/WEB-INF/jsp/addJob.jsp").forward(request, response);
        } catch (ServletException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void addJob(HttpServletRequest request, HttpServletResponse response) throws SchedulerException {
        
        String queryGroup = request.getParameter("queryGroup");
        String queryJobName = request.getParameter("queryJobName");
        if(queryGroup!=null && !"".equals(queryGroup)){
            try {
                queryGroup = URLEncoder.encode(queryGroup, "UTF-8");
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }
        }
        if(queryJobName!=null && !"".equals(queryJobName)){
            try {
                queryJobName = URLEncoder.encode(queryJobName, "UTF-8");
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }
        }
        
        String group = request.getParameter("jobGroup").trim();
        String jobName = request.getParameter("jobName").trim();
        String jobClassName = request.getParameter("jobClassName").trim();
        String[] argsNames = trimArray(request.getParameterValues("argsNames"));
        String[] argsValues = trimArray(request.getParameterValues("argsValues"));
        String triggerType = request.getParameter("triggerType").trim();
        
        Trigger trigger = null;
        if("1".equals(triggerType)){
            String rate = request.getParameter("rate").trim();
            String times = request.getParameter("times").trim();
            Integer rateInt = new Integer(rate);
            Integer timesInt = new Integer(times);
            trigger = newTrigger().
            withIdentity(jobName, group).
            withSchedule(simpleSchedule().
            withIntervalInMinutes(rateInt).
            withRepeatCount(timesInt)).build();
        }
        if("2".equals(triggerType)){
            String second = request.getParameter("secondField");
            String minute = request.getParameter("minutesField");
            String hour = request.getParameter("hourField");
            String day = request.getParameter("dayField");
            String month = request.getParameter("monthField");
            String week = request.getParameter("weekField");
            String cronExpression = String.format("%s %s %s %s %s %s", second, minute, hour, day, month, week);
            boolean isValid = CronExpression.isValidExpression(cronExpression);
            if(!isValid){
                try {
                    request.getRequestDispatcher("/WEB-INF/jsp/showError.jsp").forward(request, response);
                } catch (ServletException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            try {
                trigger = newTrigger()
                .withIdentity(jobName, group)
                .withSchedule(cronSchedule(cronExpression))
                .build();
            } catch (ParseException e) {
                e.printStackTrace();
            }
        }
        
        Scheduler scheduler = schedulerFactory.getScheduler();
        Class jobClass = null;
        try {
            jobClass = Class.forName(jobClassName);
        } catch (ClassNotFoundException e1) {
            e1.printStackTrace();
        }
        JobDetail job = newJob(jobClass).withIdentity(jobName, group).build();
        JobDataMap map = job.getJobDataMap();
        for(int i=0;i<argsNames.length;i++){
            map.put(argsNames[i], argsValues[i]);
        }
        scheduler.scheduleJob(job, trigger);
        try {
            response.sendRedirect("/setup.action?action=listJobs&queryGroup="+queryGroup+"&queryJobName="+queryJobName);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void showEditJob(HttpServletRequest request, HttpServletResponse response) throws SchedulerException {
        String queryGroup = request.getParameter("queryGroup");
        String queryJobName = request.getParameter("queryJobName");
        Scheduler scheduler = schedulerFactory.getScheduler();
        String jobKey = request.getParameter("jobKey").trim();
        String[] keyArray=jobKey.split("\\.");
        JobDetail jobDetail = scheduler.getJobDetail(JobKey.jobKey(keyArray[1],keyArray[0]));
        Trigger trigger = scheduler.getTrigger(TriggerKey.triggerKey(keyArray[1],keyArray[0]));
        request.setAttribute("jobDetail", jobDetail);
        request.setAttribute("trigger", trigger);
        request.setAttribute("queryGroup", queryGroup);
        request.setAttribute("queryJobName", queryJobName);
        if(trigger instanceof SimpleTrigger){
            request.setAttribute("triggerType", 1);
        }else{
            request.setAttribute("triggerType", 2);
        }
        List<String> jobGroups = scheduler.getJobGroupNames();
        request.setAttribute("jobGroups", jobGroups);
        try {
            request.getRequestDispatcher("/WEB-INF/jsp/editJob.jsp").forward(request, response);
        } catch (ServletException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void editJob(HttpServletRequest request, HttpServletResponse response) throws SchedulerException {
        String queryGroup = request.getParameter("queryGroup");
        String queryJobName = request.getParameter("queryJobName");
        if(queryGroup!=null && !"".equals(queryGroup)){
            try {
                queryGroup = URLEncoder.encode(queryGroup, "UTF-8");
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }
        }
        if(queryJobName!=null && !"".equals(queryJobName)){
            try {
                queryJobName = URLEncoder.encode(queryJobName, "UTF-8");
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }
        }
        String jobKey = request.getParameter("jobKey").trim();
        String triggerType = request.getParameter("triggerType").trim();
        String[] keyArray=jobKey.split("\\.");        
        Trigger trigger = null;
        if("1".equals(triggerType)){
            String rate = request.getParameter("rate").trim();
            String times = request.getParameter("times").trim();
            Integer rateInt = new Integer(rate);
            Integer timesInt = new Integer(times);
            trigger = newTrigger().
            withIdentity(keyArray[1],keyArray[0]).
            withSchedule(simpleSchedule().
            withIntervalInMinutes(rateInt).
            withRepeatCount(timesInt)).build();
        }
        
        if("2".equals(triggerType)){
            String second = request.getParameter("secondField");
            String minute = request.getParameter("minutesField");
            String hour = request.getParameter("hourField");
            String day = request.getParameter("dayField");
            String month = request.getParameter("monthField");
            String week = request.getParameter("weekField");
            String cronExpression = String.format("%s %s %s %s %s %s", second, minute, hour, day, month, week);
            boolean isValid = CronExpression.isValidExpression(cronExpression);
            if(!isValid){
                try {
                    request.getRequestDispatcher("/WEB-INF/jsp/showError.jsp").forward(request, response);
                } catch (ServletException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            try {
                trigger = newTrigger()
                .withIdentity(keyArray[1],keyArray[0])
                .withSchedule(cronSchedule(cronExpression))
                .build();
            } catch (ParseException e) {
                e.printStackTrace();
            }
        }
        Scheduler scheduler = schedulerFactory.getScheduler();
        scheduler.rescheduleJob(trigger.getKey(), trigger);
        try {
            response.sendRedirect("/setup.action?action=listJobs&queryGroup="+queryGroup+"&queryJobName="+queryJobName);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void deleteJob(HttpServletRequest request, HttpServletResponse response) throws SchedulerException {
        String queryGroup = request.getParameter("queryGroup");
        String queryJobName = request.getParameter("queryJobName");
        if(queryGroup!=null && !"".equals(queryGroup)){
            try {
                queryGroup = URLEncoder.encode(queryGroup, "UTF-8");
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }
        }
        if(queryJobName!=null && !"".equals(queryJobName)){
            try {
                queryJobName = URLEncoder.encode(queryJobName, "UTF-8");
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }
        }
        String jobKey = request.getParameter("jobKey").trim();
        String[] keyArray=jobKey.split("\\.");       
        Scheduler scheduler = schedulerFactory.getScheduler();
        scheduler.deleteJob(JobKey.jobKey(keyArray[1], keyArray[0]));
        try {
            response.sendRedirect("/setup.action?action=listJobs&queryGroup="+queryGroup+"&queryJobName="+queryJobName);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void listJobs(HttpServletRequest request, HttpServletResponse response) throws SchedulerException {
        String queryGroup = request.getParameter("queryGroup");
        String queryJobName = request.getParameter("queryJobName");
        if(queryGroup != null){
            queryGroup = queryGroup.trim();
        }
        if(queryJobName != null){
            queryJobName = queryJobName.trim();
        }
        Scheduler scheduler = schedulerFactory.getScheduler();
        List<String> groups = scheduler.getJobGroupNames();
        List<HashMap<String, Object>> jobList = new ArrayList<HashMap<String, Object>>();
        for(String group:groups){
            if(queryGroup != null && !group.contains(queryGroup)){
                continue;
            }
            Set<JobKey> jobKeys = scheduler.getJobKeys(new GroupMatcher(group, StringOperatorName.EQUALS){});
            for(JobKey jobKey : jobKeys){
                if(queryJobName!=null && !jobKey.toString().contains(queryJobName)){
                    continue;
                }
                JobDetail jobDetail = scheduler.getJobDetail(jobKey);
                HashMap<String, Object> jobInfoMap = new HashMap<String, Object>();
                List<? extends Trigger> triggers = scheduler.getTriggersOfJob(jobKey);   
                jobInfoMap.put("triggers", triggers);
                jobInfoMap.put("jobDetail", jobDetail);
                jobList.add(jobInfoMap);
            }
        }
        request.setAttribute("jobList", jobList);
        request.setAttribute("scheduler", scheduler);
        request.setAttribute("groups", groups);
        request.setAttribute("queryGroup", queryGroup);
        request.setAttribute("queryJobName", queryJobName);
        try {
            request.getRequestDispatcher("/WEB-INF/jsp/listJobs.jsp").forward(request, response);
        } catch (ServletException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    private void listJobClasses(HttpServletRequest request, HttpServletResponse response){
        request.setAttribute("jobClassesMap", jobClassesMap);
        try {
            request.getRequestDispatcher("/WEB-INF/jsp/listJobClasses.jsp").forward(request, response);
        } catch (ServletException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    private void pauseJob(HttpServletRequest request, HttpServletResponse response) throws SchedulerException {
        String queryGroup = request.getParameter("queryGroup");
        String queryJobName = request.getParameter("queryJobName");
        if(queryGroup != null){
            queryGroup = queryGroup.trim();
        }
        if(queryJobName != null){
            queryJobName = queryJobName.trim();
        }
        String jobKey = request.getParameter("jobKey").trim();
        String[] keyArray=jobKey.split("\\.");       
        Scheduler scheduler = schedulerFactory.getScheduler();
        scheduler.pauseJob(JobKey.jobKey(keyArray[1], keyArray[0]));
        try {
            response.sendRedirect("/setup.action?action=listJobs&queryGroup="+queryGroup+"&queryJobName="+queryJobName);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    private void resumeJob(HttpServletRequest request, HttpServletResponse response) throws SchedulerException {
        String queryGroup = request.getParameter("queryGroup");
        String queryJobName = request.getParameter("queryJobName");
        if(queryGroup != null){
            queryGroup = queryGroup.trim();
        }
        if(queryJobName != null){
            queryJobName = queryJobName.trim();
        }
        String jobKey = request.getParameter("jobKey").trim();
        String[] keyArray=jobKey.split("\\.");       
        Scheduler scheduler = schedulerFactory.getScheduler();
        scheduler.resumeJob(JobKey.jobKey(keyArray[1], keyArray[0]));
        try {
            response.sendRedirect("/setup.action?action=listJobs&queryGroup="+queryGroup+"&queryJobName="+queryJobName);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    private void pauseOrRunAllJobs(HttpServletRequest request, HttpServletResponse response) throws SchedulerException {
        String queryGroup = request.getParameter("queryGroup");
        String queryJobName = request.getParameter("queryJobName");
        String type = request.getParameter("type");
        if(queryGroup != null){
            queryGroup = queryGroup.trim();
        }
        if(queryJobName != null){
            queryJobName = queryJobName.trim();
        }
        Scheduler scheduler = schedulerFactory.getScheduler();
        String[] jobsInfo = request.getParameterValues("jobsInfo");
        for(String jobKey:jobsInfo){
            String[] keyArray=jobKey.split("\\."); 
            if("1".equals(type)){
                scheduler.pauseJob(JobKey.jobKey(keyArray[1], keyArray[0]));
            }
            if("2".equals(type)){
                scheduler.resumeJob(JobKey.jobKey(keyArray[1], keyArray[0]));
            }
        }
        try {
            response.sendRedirect("/setup.action?action=listJobs&queryGroup="+queryGroup+"&queryJobName="+queryJobName);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    private void executeOnce(HttpServletRequest request, HttpServletResponse response) throws SchedulerException {
        String queryGroup = request.getParameter("queryGroup");
        String queryJobName = request.getParameter("queryJobName");
        if(queryGroup != null){
            queryGroup = queryGroup.trim();
        }
        if(queryJobName != null){
            queryJobName = queryJobName.trim();
        }
        String jobKey = request.getParameter("jobKey").trim();
        String[] keyArray=jobKey.split("\\.");       
        Scheduler scheduler = schedulerFactory.getScheduler();
        Trigger trigger = newTrigger().
        withIdentity(keyArray[1]+UUID.randomUUID().toString(), keyArray[0]).
        withPriority(100).
        forJob(JobKey.jobKey(keyArray[1], keyArray[0])).
        build();
        scheduler.scheduleJob(trigger);
        try {
            response.sendRedirect("/setup.action?action=listJobs&queryGroup="+queryGroup+"&queryJobName="+queryJobName);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    private void getAllJobClasses(String basePath, String jobPackage){
        String currentPackageName = jobPackage.replace(basePath, "").replaceAll("/", "\\.");
        List<String> classesList = new ArrayList<String>();
        File packageFolder = new File(jobPackage);
        File[] jobClassFiles = packageFolder.listFiles();
        if(jobClassFiles != null && jobClassFiles.length > 0){
            for(File jobClassFile : jobClassFiles){
                if(jobClassFile.isDirectory()){
                    try {
                        getAllJobClasses(basePath, jobClassFile.getCanonicalPath());
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }else if(jobClassFile.getName().matches(".*\\.class")){
                    classesList.add(currentPackageName + "." + jobClassFile.getName().replaceAll("\\.class", ""));
                }
            }
        }
        if(classesList.size() > 0){
            jobClassesMap.put(currentPackageName, classesList);
        }
    }
    
    private String trim(String param){
        if(param!=null){
            param = param.trim();
        }
        return param;
    }
    private String[] trimArray(String[]array){
        if(array!=null){
            for(int i =0;i<array.length;i++){
                if(array[i]!=null){
                    array[i]=trim(array[i]);
                }
            }
        }
        return array;
    }
}
