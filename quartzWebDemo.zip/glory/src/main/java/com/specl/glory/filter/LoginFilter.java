package com.specl.glory.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class LoginFilter implements Filter {

    private FilterConfig config = null;
    private String LOGIN_NAME,PASSWORD = null;
    private static final String USER_LOGIN_NAME_COOKIES_NAME = "un";
    private static final String USER_PASSWD_COOKIES_NAME = "pwd";
    
    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        this.config = filterConfig;
        this.LOGIN_NAME = config.getInitParameter("LOGIN_NAME");
        this.PASSWORD = config.getInitParameter("PASSWORD");
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException,ServletException {
        HttpServletRequest req = (HttpServletRequest)request;
        HttpServletResponse res = (HttpServletResponse)response;
        
        String userName = getCookie(req, USER_LOGIN_NAME_COOKIES_NAME);
        String password = getCookie(req, USER_PASSWD_COOKIES_NAME);
        
        if(!LOGIN_NAME.equals(userName) || !PASSWORD.equals(password)){
            res.sendRedirect("login.do?action=showLogin");
            return;
        }
        chain.doFilter(request, response);
        return;
    }

    @Override
    public void destroy() {
        config = null;
        LOGIN_NAME=null;
        PASSWORD = null;
    }

    private  String getCookie(HttpServletRequest request,String cookieName){
        Cookie[] cookies = request.getCookies();
        String str = null;
        if (cookies != null) {
            for (int i = 0; i < cookies.length; i++) {
                Cookie c = cookies[i];
                if (c.getName().equalsIgnoreCase(cookieName)) {
                    str = c.getValue();
                }
            }
        }
        return str;
    }
}
